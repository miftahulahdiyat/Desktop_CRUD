
package kuis;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.stage.Stage;



public class FXMLDocumentController implements Initializable {
    
   
    
    

    @FXML
    private DatePicker tanggal;

    @FXML
    private TextField harga;

    @FXML
    private Button simpan;

    @FXML
    private ComboBox<String> jenis;

    @FXML
    private TextField merek;

    @FXML
    private TextField warna;
    @FXML
    private Button data;

    void initialize() {
        assert tanggal != null : "fx:id=\"tanggal\" was not injected: check your FXML file 'FXMLDocument.fxml'.";
        assert harga != null : "fx:id=\"harga\" was not injected: check your FXML file 'FXMLDocument.fxml'.";
        assert simpan != null : "fx:id=\"simpan\" was not injected: check your FXML file 'FXMLDocument.fxml'.";
        assert jenis != null : "fx:id=\"jenis\" was not injected: check your FXML file 'FXMLDocument.fxml'.";
        assert merek != null : "fx:id=\"merek\" was not injected: check your FXML file 'FXMLDocument.fxml'.";
        assert warna != null : "fx:id=\"warna\" was not injected: check your FXML file 'FXMLDocument.fxml'.";

    }
    
    
   
    @FXML
    private void handleButtonAction(ActionEvent event) throws SQLException {
       
       VGACardDataModel datamodel = new VGACardDataModel();
        
       VGACard vga = new VGACard();
       vga.setTanggal_pembelian(tanggal.getValue().toString());
       vga.setMerek(merek.getText());
       vga.setHarga(Integer.parseInt(harga.getText()));
       vga.setJenis(jenis.getValue());
       vga.setWarna(warna.getText());
       
       datamodel.addVGAcard(vga);
        
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
       ArrayList <String> list = new ArrayList<String>();
        list.add("NVDIA GTX 1650");
        list.add("NVDIA RTX 3060");
        list.add("RADEON RX6500 XT ");
        list.add("RADEON PRO W6800");
        ObservableList items = FXCollections.observableArrayList(list);
        jenis.setItems(items);
     
    }  
    
    private Parent root;
    private Scene scene;
    private Stage stage;
    
    @FXML
    public void switchToSceneData(ActionEvent event) throws IOException{
       
        FXMLLoader loader =  new FXMLLoader(getClass().getResource("FXMLData.fxml"));
        root = loader.load();
        FXMLDataController datacontroller = loader.getController();
        datacontroller.showInformation(merek.getText());
        scene =  new Scene(root);
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    } 
}
